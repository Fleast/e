const mediamenu = (prefix) => { 
	return `
╭─「 *MEDIA DOWNLOADER* 」──
│
├➲ *${prefix}tiktokstalk [username]*
├➲ *${prefix}igstalk [muhmdilhan_]*
├➲ *${prefix}insta [Link]*
├➲ *${prefix}instastory [username]*
├➲ *${prefix}ssweb [url]*
├➲ *${prefix}url2img [Url]*
├➲ *${prefix}tiktok*
├➲ *${prefix}fototiktok*
├➲ *${prefix}meme*
├➲ *${prefix}memeindo*
├➲ *${prefix}kbbi*
├➲ *${prefix}wait*
├➲ *${prefix}trendtwit*
├➲ *${prefix}google [berita terkini]*
├➲ *${prefix}pinterest*
├➲ *${prefix}play*
│
╰──────────────────────
	
                  *©Henbai BOT*`
	}
exports.mediamenu = mediamenu