const funmenu = (prefix) => { 
	return ` 
╭───「 *FUN & GAME* 」──
│
├➲ *${prefix}anjing*
├➲ *${prefix}kucing*
├➲ *${prefix}testime*
├➲ *${prefix}hilih*
├➲ *${prefix}say*
├➲ *${prefix}apakah*
├➲ *${prefix}kapankah*
├➲ *${prefix}bisakah*
├➲ *${prefix}rate*
├➲ *${prefix}watak*
├➲ *${prefix}hobby*
├➲ *${prefix}infogempa*
├➲ *${prefix}infonomor* 
├➲ *${prefix}quotes*
├➲ *${prefix}truth*
├➲ *${prefix}dare*
├➲ *${prefix}katabijak*
├➲ *${prefix}fakta*
├➲ *${prefix}darkjokes*
├➲ *${prefix}bucin*
├➲ *${prefix}pantun*
├➲ *${prefix}katacinta*
├➲ *${prefix}jadwaltvnow*
├➲ *${prefix}hekerbucin*
├➲ *${prefix}katailham*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
│
╰───────────────────
	
               *©Hanbei BOT*`
	}
exports.funmenu = funmenu